##' @importFrom methods setOldClass
setOldClass("enrichResultList")
setOldClass("gseaResultList")
